﻿using System;
using System.Windows.Forms;

namespace Usando_Forms
{
    public partial class Marca : Form
    {
        public Marca()
        {
            InitializeComponent();
        }

        public static Marca staticVariavel = null;

        private void button1_Click(object search, EventArgs e )
        {
            lblIdMarca.Text = txtIdMarca.Text;
            lblNome.Text = txtNome.Text;
         
        }
        private void button2_Click(object edit, EventArgs e)
        {
            lblIdMarca.Text = txtIdMarca.Text;
            lblNome.Text = txtNome.Text;
  
        }
        private void btnDelete_Click(object clear, EventArgs e)
        {
            lblIdMarca.Text = txtIdMarca.Text;
            lblNome.Text = txtNome.Text;
    
        }
 

        public static T OpenOrCreateForm<T>() where T : Form, new()
        {
            T result;
            // Test if form exists
            foreach (Form form in Application.OpenForms)
            {
                result = form as T;

                if (!Object.ReferenceEquals(null, result))
                {
                    // Form found; and this is the right place 
                    //  to restore form size,
                    //  bring form to front etc.
                    if (result.WindowState == FormWindowState.Minimized)
                        result.WindowState = FormWindowState.Normal;

                    result.BringToFront();
                    return result;
                }
            }

            // Form doesn't exist, let's create it
            result = new T();
            // Probably, you want to show the created form
            result.Show();
            return result;
        }

       
    }
}
