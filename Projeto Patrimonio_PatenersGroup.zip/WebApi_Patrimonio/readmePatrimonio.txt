namespace WebApi2_Patrimonio.Models
{
    // PUBLICA��O DA CLASSE PATRIMONIO E DECLARA��O DAS VARIAVEIS : IDMARCA, NOME, DESCRICAO, NTOMBO // 
    public class Patrimonio
    {
        public int IdMarca { get; set; }
        public string Nome { get; set; }
        public string Descricao { get; set; }
        public decimal nTombo { get; set; }
        
    }

   
}

// -----------------------------------------------------------------------------//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi2_Patrimonio.Models
{
    //  DECLARA��O DA  INTERGACE IPATRIMONIO E PARAMETRO DE ADI��O E VISUALIZA��O DO ID NA CLASSE PATRIMONIO //
    public interface IPatrimonio
    {
        IEnumerable<Patrimonio> GetAll();
        Patrimonio Get(int id);
        Patrimonio Add(Patrimonio item);
        void Remove(int id);
        bool Update(Patrimonio item);
    }
}

// -----------------------------------------------------------------------------//

using System;
using System.Collections.Generic;

// CLASSE PATRIMONIO DECLARA��O DAS VARIAVEIS PARA INSER��O AUTOMATICA DOS DADOS IDMARCA E NTOMBO. //

namespace WebApi2_Patrimonio.Models
{
    public class PatrimonioDados : IPatrimonio
    {
        private List<Patrimonio> patrimonio = new List<Patrimonio>();
        private int _nextId = 1;
        private int _nextnTombo = 1;

        public PatrimonioDados()
        {
            Add(new Patrimonio { Nome = "CONDOMINIO JK-VILLAGE", Descricao = "CONDOMINIO COM 15.000 M�, PROX. AO IBIRAPUERA", });
            Add(new Patrimonio { Nome = "PALACIO DO GOVERNO ", Descricao = "AREA DE 30.000 M�. LOCALIZADO NO JD. GUEDALA",  });

        }

   
        // PARAMETRO DE ADI��O DE IDMARCA AUTOMATICO NA CLASSE PATRIMONIO STRING IDMARCA. //

        public Patrimonio Add(Patrimonio item)
        {
            if(item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.IdMarca = _nextId++;
            patrimonio.Add(item);
            return item;
        }
        
        // PARAMETRO DE ADI��O DE NTOMBO AUTOMATICO NA CLASSE PATRIMONIO STRING NTOMBO. //
        public Patrimonio Add(Patrimonio item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.nTombo = _nextnTombo;
            patrimonio.Add(item);
            return item;
        }

        // PARAMETRO DE REMO��O DE IDMARCA ADICIONADO NA CLASSE PATRIMONIO STRING IDMARCA. //

        public Patrimonio Get(int id)
        {
            return patrimonio.Find(p => p.IdMarca == id);
        }

        public IEnumerable<Patrimonio> GetAll()
        {
            return patrimonio;
        }

        public void Remove(int id)
        {
            patrimonio.RemoveAll(p => p.IdMarca == id);
        }

        // PARAMETRO DE UPDATE(ATUALIZA��O) DOS DADOS NA CLASSE PATRIMONIO STRING IDMARCA. //

        public bool Update(Patrimonio item)
        {
            if( item == null)
            {
                throw new ArgumentNullException("item");
            }

            int index = patrimonio.FindIndex(p => p.IdMarca == item.IdMarca);

            if(index == -1)
            {
                return false;
            }
            patrimonio.RemoveAt(index);
            patrimonio.Add(item);
            return true;
        }
    }

  
}

 // ---------------------------------------------------------------------------//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApi2_Patrimonio.Models;


namespace WebApi2_Patrimonio.Controllers
{
    //  DECLARA��O DA CLASSE PATRIMONIOCONTROLLER //
    public class PatrimonioController : ApiController
    {
        static readonly IPatrimonio repositorio = new PatrimonioDados();

        public IEnumerable<Patrimonio> GetAllPatrimonio()
        {
            return repositorio.GetAll();
        }
        //  PARAMETRO DE ADI��O DE NOVO ID NA CLASSE PATRIMONIO //
        public Patrimonio GetPatrimonio(int id)
        {
            Patrimonio item = repositorio.Get(id);
            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound); 
            }
            return item;
        }

        public IEnumerable<Patrimonio> GetPatrimonioPorCategoria(string descricao)
        {
            return repositorio.GetAll().Where(
                p => string.Equals(p.Descricao, descricao, StringComparison.OrdinalIgnoreCase));
        }

        public HttpResponseMessage PostPatrimonio(Patrimonio item)
        {
            item = repositorio.Add(item);
            var response = Request.CreateResponse<Patrimonio>(HttpStatusCode.Created, item);

            string uri = Url.Link("DefaultApi", new { id = item.IdMarca });
            response.Headers.Location = new Uri(uri);
            return response;
        }

        //  PARAMETRO DE UPDATE DE DADOS REFETENTE A VARIAVEL ID NA CLASSE PATRIMONIO //

        public void PutPatrimonio(int id, Patrimonio patrimonio)
        {
            patrimonio.IdMarca = id;
            if (!repositorio.Update(patrimonio))
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
        }

        //  PARAMETRO DE DELETE DE ID NA CLASSE PATRIMONIO //
        public void DeletePatrimonio(int id)
        {
            Patrimonio item = repositorio.Get(id);

            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }

            repositorio.Remove(id);
        }
    }
}

// -----------------------------------------------------------------------------//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApi2_Patrimonio.Controllers
    // EXIBI��O DA INDEX HOMECONTROLLER, COM A PUBLICA��O DO T�TULO DA WEBAPI // 
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";

            return View();
        }
    }
}
