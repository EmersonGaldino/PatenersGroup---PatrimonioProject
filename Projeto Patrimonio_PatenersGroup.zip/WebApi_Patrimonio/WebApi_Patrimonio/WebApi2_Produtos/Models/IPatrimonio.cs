﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApi2_Patrimonio.Models
{
    //  DECLARAÇÃO DA  INTERGACE IPATRIMONIO E PARAMETRO DE ADIÇÃO E VISUALIZAÇÃO DO ID NA CLASSE PATRIMONIO //
    public interface IPatrimonio
    {
        IEnumerable<Patrimonio> GetAll();
        Patrimonio Get(int id);
        Patrimonio Add(Patrimonio item);
        void Remove(int id);
        bool Update(Patrimonio item);
    }
}
