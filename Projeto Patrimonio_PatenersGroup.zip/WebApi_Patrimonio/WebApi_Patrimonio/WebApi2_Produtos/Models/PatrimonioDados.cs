﻿using System;
using System.Collections.Generic;

// CLASSE PATRIMONIO DECLARAÇÃO DAS VARIAVEIS PARA INSERÇÃO AUTOMATICA DOS DADOS IDMARCA E NTOMBO. //

namespace WebApi2_Patrimonio.Models
{
    public class PatrimonioDados : IPatrimonio
    {
        private List<Patrimonio> patrimonio = new List<Patrimonio>();
        private int _nextId = 1;
        private int _nextnTombo = 1;

        public PatrimonioDados()
        {
            Add(new Patrimonio { Nome = "CONDOMINIO JK-VILLAGE", Descricao = "CONDOMINIO COM 15.000 M², PROX. AO IBIRAPUERA", });
            Add(new Patrimonio { Nome = "PALACIO DO GOVERNO ", Descricao = "AREA DE 30.000 M². LOCALIZADO NO JD. GUEDALA",  });

        }

   
        // PARAMETRO DE ADIÇÃO DE IDMARCA AUTOMATICO NA CLASSE PATRIMONIO STRING IDMARCA. //

        public Patrimonio Add(Patrimonio item)
        {
            if(item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.IdMarca = _nextId++;
            patrimonio.Add(item);
            return item;
        }
        
        // PARAMETRO DE ADIÇÃO DE NTOMBO AUTOMATICO NA CLASSE PATRIMONIO STRING NTOMBO. //
        public Patrimonio Add(Patrimonio item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.nTombo = _nextnTombo;
            patrimonio.Add(item);
            return item;
        }

        // PARAMETRO DE REMOÇÃO DE IDMARCA ADICIONADO NA CLASSE PATRIMONIO STRING IDMARCA. //

        public Patrimonio Get(int id)
        {
            return patrimonio.Find(p => p.IdMarca == id);
        }

        public IEnumerable<Patrimonio> GetAll()
        {
            return patrimonio;
        }

        public void Remove(int id)
        {
            patrimonio.RemoveAll(p => p.IdMarca == id);
        }

        // PARAMETRO DE UPDATE(ATUALIZAÇÃO) DOS DADOS NA CLASSE PATRIMONIO STRING IDMARCA. //

        public bool Update(Patrimonio item)
        {
            if( item == null)
            {
                throw new ArgumentNullException("item");
            }

            int index = patrimonio.FindIndex(p => p.IdMarca == item.IdMarca);

            if(index == -1)
            {
                return false;
            }
            patrimonio.RemoveAt(index);
            patrimonio.Add(item);
            return true;
        }
    }

  
}