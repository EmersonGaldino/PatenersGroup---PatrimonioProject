﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApi2_Patrimonio.Models;


namespace WebApi2_Patrimonio.Controllers
{
    //  DECLARAÇÃO DA CLASSE PATRIMONIOCONTROLLER //
    public class PatrimonioController : ApiController
    {
        static readonly IPatrimonio repositorio = new PatrimonioDados();

        public IEnumerable<Patrimonio> GetAllPatrimonio()
        {
            return repositorio.GetAll();
        }
        //  PARAMETRO DE ADIÇÃO DE NOVO ID NA CLASSE PATRIMONIO //
        public Patrimonio GetPatrimonio(int id)
        {
            Patrimonio item = repositorio.Get(id);
            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound); 
            }
            return item;
        }

        public IEnumerable<Patrimonio> GetPatrimonioPorCategoria(string descricao)
        {
            return repositorio.GetAll().Where(
                p => string.Equals(p.Descricao, descricao, StringComparison.OrdinalIgnoreCase));
        }

        public HttpResponseMessage PostPatrimonio(Patrimonio item)
        {
            item = repositorio.Add(item);
            var response = Request.CreateResponse<Patrimonio>(HttpStatusCode.Created, item);

            string uri = Url.Link("DefaultApi", new { id = item.IdMarca });
            response.Headers.Location = new Uri(uri);
            return response;
        }

        //  PARAMETRO DE UPDATE DE DADOS REFETENTE A VARIAVEL ID NA CLASSE PATRIMONIO //

        public void PutPatrimonio(int id, Patrimonio patrimonio)
        {
            patrimonio.IdMarca = id;
            if (!repositorio.Update(patrimonio))
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
        }

        //  PARAMETRO DE DELETE DE ID NA CLASSE PATRIMONIO //
        public void DeletePatrimonio(int id)
        {
            Patrimonio item = repositorio.Get(id);

            if (item == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }

            repositorio.Remove(id);
        }
    }
}
